import java.util.Scanner;

public class TipCalculator {

    public static float calculateTip(float billAmount, int rating) {
        float tipAmount = 0.0f;
        
        if (rating == 1) {
            tipAmount = billAmount * 0.05f; 
        } else if (rating == 2) {
            tipAmount = billAmount * 0.08f; 
        } else if (rating == 3) {
            tipAmount = billAmount * 0.10f;
        } else if (rating == 4) {
            tipAmount = billAmount * 0.15f; // 
        } else if (rating == 5) {
            tipAmount = billAmount * 0.20f;
        }
        return tipAmount;
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in); 
        String name = "Surrinder"; 
        float billAmount;
        int rating;
        float tipAmount;

        System.out.print("Enter the bill amount: ");
        billAmount = sc.nextFloat();

        System.out.print("Enter rating (1-5): ");
        rating = sc.nextInt();

        tipAmount = calculateTip(billAmount, rating);

        System.out.println(name + ", your tip amount is \u20B9: " + tipAmount);
        
        sc.close(); 
    }
}
